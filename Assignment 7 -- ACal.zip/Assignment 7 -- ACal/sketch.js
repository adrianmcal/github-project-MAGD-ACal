let reverse = false
let clickNum = 0
let loopNum = 0
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(160,180,235);
  for(let i = 0; i<clickNum; i++){
  knight(0+i,0+i)
  }
  if(clickNum<25&&reverse==false){
  clickNum+=1
  }else if(clickNum>0){
    reverse = true
    clickNum -= 1
  }else{
    reverse = false
    print(returnValue())
  }
}

function knight(x, y){
  translate(x,y)
  angleMode(DEGREES)
  rotate(x/1.5)
  scale(pow(x,-0.1),pow(y,-0.1))
  noStroke()
  push()
  stroke(115)
  strokeWeight(4)
  line(370,255,260,255)
  line(315,215,335,330)
  line(315,215,295,330)
  pop()
  fill(115)
  ellipse(315,265,50,70)
  fill(215,0,0)
  rect(310,260,10,30)
  rect(303,265,24,10)
  fill(145)
  rect(300,200,30,45)
  fill(0)
  rect(302,210,10,5)
  rect(318,210,10,5)
  stroke(6)
  line(365,265,365,140)
  line(355,245,375,245)
}
function returnValue(){
  loopNum +=1
  return "Number of loops: " + loopNum
}