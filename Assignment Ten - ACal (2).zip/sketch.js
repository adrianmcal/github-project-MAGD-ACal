const pieces = [];
const testArray = ['hi','hello']
let img;
let gameStarted = false;
let startButton;
pieceChosen = false


function preload() {
  img = loadImage("perfectCell.jpg");
}

function setup() {
  createCanvas(400, 400);
  startButton = createButton("New Puzzle");
  startButton.mousePressed(startGame);
  for (let x = 0; x < 4; x++) {
    for (let y = 0; y < 4; y++){
      pieces.push(img.get(x*100,y*100,100,100))
    }
  }
}

function draw() {
  if (gameStarted == true) {
    background(220);
    drawQuadrille(createQuadrille(4,pieces));
    let c = createQuadrille(1,1)
    //print('pieces: '+ pieces + 'done')
    drawQuadrille(c, { row: c.mouseRow, col: c.mouseCol, outline: 'lime' });
    if(pieceChosen == true){
    image(img.get(floor(fixedMouseY/100)*100,floor(fixedMouseX/100)*100,100,100),mouseX-50,mouseY-50)
    }
  }
}

function mouseClicked(){
  if(pieceChosen == false){
  fixedMouseX = mouseX
  fixedMouseY = mouseY
  pieceChosen = true
  }else{
  pieceChosen = false
  }
}

function startGame() {
  startButton.remove();
  gameStarted = true;
}
