let heartX;
let heartY;
let heartProx;
let catLeft;
let catRight;
let heartClick;
let win = false;
let fourSecondCounter = 0;

function preload() {
  spawnNewHeart();
  catLeft = loadImage("Cat00.jpg");
  catRight = loadImage("Cat01.jpg");
  heartClick = loadImage("Heart.png");
  heartGif = loadImage("Love.gif");
  pawCursor = loadImage("Paw.png");
}

function setup() {
  createCanvas(400, 400);
  background(120);
}

function draw() {
  if (win == false) {
    background("cornflowerblue");

    noStroke();
    fill(60, 150, 40);
    rect(0, 200, 400, 200);
    textFont("Papyrus");
    textSize(16);
    fill("black");
    text("Click the Heart!", 180, 300, 20, 60);
    //fill("yellow");
    heartProx = Math.trunc(dist(mouseX, mouseY, heartX + 32, heartY + 34));
    //print(heartX, heartY)
    //print(heartX, heartY)
    image(heartClick, heartX, heartY);
    //text(heartProx, mouseX, mouseY);

    image(catRight, Math.min(320, 185 + (145 * heartProx) / 300), 160);
    //text('catRight: ' + (Math.trunc(Math.min(320,(300*(heartProx/175))))),320,140)

    image(catLeft, Math.max(0, 140 * (1 - heartProx / 300)), 160);
    //text('catLeft: ' + (Math.trunc(Math.max(0,(150*(1-heartProx/300))))),10,140)

    image(pawCursor, mouseX - 10, mouseY - 10);
  } else {
    loveAnimation();
    fourSecondCounter += 1;
  }
}

function mouseClicked() {
  if (
    mouseX >= heartX + 8 &&
    mouseX <= heartX + 58 &&
    mouseY >= heartY + 8 &&
    mouseY <= heartY + 58
  ) {
    win = true;
    fourSecondCounter = 0;
  }
}

function spawnNewHeart() {
  heartX = random(0, 192);
  if (heartX >= 96) {
    heartX += 144;
  }
  heartY = random(0, 192);
  if (heartY >= 96) {
    heartY += 144;
  }
}

function loveAnimation() {
  if (fourSecondCounter < 240) {
    fill("cornflowerblue");
    square(140, 20, 128);
    image(heartGif, 140, 20);
  } else {
    spawnNewHeart();
    image(heartClick, heartX, heartY);
    win = false;
  }
}
