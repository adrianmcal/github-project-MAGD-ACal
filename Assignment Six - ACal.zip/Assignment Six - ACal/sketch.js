const snakeSize = [];
let x = 200;
let y = 200;
let foodX = 0;
let fooxY = 0;
let foodEaten = 0;
let trail = false;
let mouseMode = false;

function setup() {
  let toggleMouseMode = createButton('Toggle Mouse Mode')
  toggleMouseMode.position(135,405);
  toggleMouseMode.mousePressed(toggle)
  createCanvas(400, 400);
  foodX = random(20, 380);
  foodY = random(20, 380);
  fill(255, 0, 0);
}

function draw() {
  background(220);
  fill(0);
  text("Food Eaten:" + foodEaten, 160, 40);
  fill("red");
  circle(foodX, foodY, 20);
  fill(255);
  movement();

  circle(x, y, 20);
  if (
    x <= foodX + 20 &&
    x >= foodX - 20 &&
    y <= foodY + 20 &&
    y >= foodY - 20
  ) {
    foodEaten += 1;
    foodSpawn();
    print("Array Length:", snakeSize.length + 1);
  }
  snakeGrow();
  snakeSize[0] = { x, y };
  noStroke();
}
function movement() {
  if (mouseMode == false){
  if (keyIsDown(65)) {
    x -= 2;
  }
  if (keyIsDown(68)) {
    x += 2;
  }
  if (keyIsDown(87)) {
    y -= 2;
  }
  if (keyIsDown(83)) {
    y += 2;
  }
}else{
  x = mouseX
  y = mouseY
}
}
function toggle(){
  mouseMode = !mouseMode;
}
function foodSpawn() {
  foodX = random(20, 380);
  foodY = random(20, 380);
}
function snakeGrow() {
  fill(255);
  for (let i = foodEaten; i > 0; i--) {
    snakeSize[i] = snakeSize[i - 1];
    circle(snakeSize[i].x, snakeSize[i].y, 20);
  }
}
